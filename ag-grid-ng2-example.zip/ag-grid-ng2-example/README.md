
ag-Grid
==============

Example of using ag-Grid with Angular2 and TypeScript

Building
==============

To build:
- `npm install`
- `npm run tsc`

To Run:
- `npm run lite`
